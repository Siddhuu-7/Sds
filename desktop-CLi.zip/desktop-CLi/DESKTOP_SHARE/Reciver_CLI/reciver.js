const net = require('net');
const fs = require('fs');

const PATH = require('./Path/path');
const FolderCreation = require('./Path/FolderCreation/Folder_creation');
const Broadcaster = require("../UDP/udp"); 
const getIp = require("../UDP/getIp").getIp;

const PORT = 6961;

class FileReceiver {
    constructor(port = PORT) {
        this.port = port;
        this.IP = getIp();
        this.server = net.createServer(this.handleConnection.bind(this));
        this.broadcaster = new Broadcaster();
    }

    handleConnection(socket) {
        let fileStream;
        let receivedBytes = 0;
        let FileSavePath;

        socket.once('data', (chunk) => {
            const str = chunk.toString();
            const newlineIndex = str.indexOf('\n');
            const filename = str.slice(0, newlineIndex).trim();

            FileSavePath = PATH(filename);
            console.log(`[RECEIVE] Receiving file: ${filename}`);

            fileStream = fs.createWriteStream(FileSavePath);

            const restBuffer = chunk.slice(newlineIndex + 1);
            receivedBytes += restBuffer.length;
            fileStream.write(restBuffer);

            socket.on('data', (chunk) => {
                receivedBytes += chunk.length;
                process.stdout.write(`Received ${Math.round(receivedBytes / (1024 * 1024))} MB\r`);
            });

            socket.pipe(fileStream);
        });

        socket.on('end', () => {
            console.log('\n[RECEIVE] File received successfully');
            if (fileStream) fileStream.end();
        });

        socket.on('close', () => console.log('[INFO] Client disconnected'));

        socket.on('error', (err) => {
            console.error('[ERROR] Socket error:', err);
            if (fileStream) fileStream.destroy();
        });
    }

    async waitForIP(checkFn, interval = 3000) {
        return new Promise((resolve) => {
            const timer = setInterval(() => {
                const ip = checkFn();
                if (ip) {
                    clearInterval(timer);
                    resolve(ip);
                }
            }, interval);
        });
    }

    async start() {
        if (!this.IP) {
            process.stdout.write("[INFO] Connect to the same network as your sender...\n");
            this.IP = await this.waitForIP(getIp);
        }

        this.server.listen(this.port, this.IP, () => {
            FolderCreation();
            this.broadcaster.init();
            this.broadcaster.start();
            console.log(`[SERVER] Receiver running at ${this.IP}:${this.port}`);
        });
    }
}

const receiver = new FileReceiver();
receiver.start();
