const net = require('net');
const fs = require('fs');
const {getDesktopPath,pathCheck} = require('./Path/path');
const FolderCreation = require('./Path/FolderCreation/Folder_creation');
const Broadcaster = require("../UDP/udp"); 
const getIp = require("../UDP/getIp").getIp;
const ZIP=require("../Sender_CLI/SENDER_CLI/FolderOPeration/FolderZip")
const PORT = 6961;
class FileReceiver {
    constructor(port = PORT) {
        this.port = port;
        this.IP = getIp();
        this.server = net.createServer(this.handleConnection.bind(this));
        this.broadcaster = new Broadcaster();
        this.filepath=""
        this.filename=""
        this.zip=new ZIP();
    }
    handleConnection(socket) {
        let fileStream;
        let receivedBytes = 0;
       socket.once('data', (chunk) => {
    const str = chunk.toString();
    const newlineIndex = str.indexOf('\n');
    this.filename = str.slice(0, newlineIndex).trim();
    this.filepath = getDesktopPath(this.filename);
    console.log(`[RECEIVE] Receiving file: ${this.filename}`);
    const fileStream = fs.createWriteStream(this.filepath);
    const restBuffer = chunk.slice(newlineIndex + 1);
    let receivedBytes = restBuffer.length;
    if (restBuffer.length > 0) fileStream.write(restBuffer);
    socket.on('data', (chunk) => {
        receivedBytes += chunk.length;
        process.stdout.write(`Received ${Math.round(receivedBytes / (1024 * 1024))} MB\r`);
        fileStream.write(chunk);
    });

    socket.on('end', () => {
        fileStream.end();
        console.log(`\n✅ File received: ${this.filepath}`);
    });

    socket.on('error', (err) => {
        console.error(`❌ Socket error: ${err.message}`);
        fileStream.end();
    });
});


        socket.on('end', () => {
            
            if (fileStream) fileStream.end();
            if (this.filename.toLowerCase().endsWith('.zip')) {
                console.log("[INFO] Detected ZIP file, extracting...");

                try {
                     this.zip.unZipping(this.filepath,getDesktopPath()).then(path=>{
                        console.log('\n[RECEIVE] File received successfully');
                     })
                    console.log("[INFO] ZIP extraction completed successfully!");
                } catch (err) {
                    console.error("[ERROR] Failed to extract ZIP:", err.message);
                }
            }
        });

        socket.on('close', () => console.log('[INFO] Client disconnected'));

        socket.on('error', (err) => {
            console.error('[ERROR] Socket error:', err);
            if (fileStream) fileStream.destroy();
        });
    }

    async waitForIP(checkFn, interval = 3000) {
        return new Promise((resolve) => {
            const timer = setInterval(() => {
                const ip = checkFn();
                if (ip) {
                    clearInterval(timer);
                    resolve(ip);
                }
            }, interval);
        });
    }

    async start() {
        if (!this.IP) {
            process.stdout.write("[INFO] Connect to the same network as your sender...\n");
            this.IP = await this.waitForIP(getIp);
        }

        this.server.listen(this.port, this.IP, () => {
            FolderCreation();
            this.broadcaster.init();
            this.broadcaster.start();
            console.log(`[SERVER] Receiver running at ${this.IP}:${this.port}`);
        });
    }
}

const receiver = new FileReceiver();
receiver.start();
