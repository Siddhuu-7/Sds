
const os=require('os')
const fs = require("fs");
const path = require("path");

module.exports=(fileName)=>{
    let DesktopPath = path.join(os.homedir(), 'Desktop','DESKTOP SHARE');
    if(!fs.existsSync(DesktopPath)){
        const oneDriveDesktop = path.join(os.homedir(), 'OneDrive', 'Desktop','DESKTOP SHARE');
        if(fs.existsSync(oneDriveDesktop)){
            DesktopPath=oneDriveDesktop;
        }
    }
    return path.join(DesktopPath,fileName)
}




