const os = require('os');
const fs = require('fs');
const path = require('path');

function getDesktopPath(fileName = '/') {
    let DesktopPath = path.join(os.homedir(), 'Desktop', 'DESKTOP SHARE');

    if (!fs.existsSync(DesktopPath)) {
        const oneDriveDesktop = path.join(os.homedir(), 'OneDrive', 'Desktop', 'DESKTOP SHARE');
        if (fs.existsSync(oneDriveDesktop)) {
            DesktopPath = oneDriveDesktop;
        }
    }

    return path.join(DesktopPath, fileName);
}

function pathCheck(filepath) {
    console.log(filepath)
    if (!fs.existsSync(filepath)) return filepath;

    const dir = path.dirname(filepath);
    const ext = path.extname(filepath);
    const base = path.basename(filepath, ext);
    let counter = 1;
    let newPath = path.join(dir, `${base}(${counter})${ext}`);

    while (fs.existsSync(newPath)) {
        counter++;
        newPath = path.join(dir, `${base}(${counter})${ext}`);
    }
    console.log("New Name "+newPath)
    return newPath;
}

module.exports = { getDesktopPath, pathCheck };
