const fs = require('fs');
const path = require('path');
const os = require('os');

module.exports = () => {

    let DesktopPath = path.join(os.homedir(), 'Desktop');

    if (!fs.existsSync(DesktopPath)) {
        const oneDriveDesktop = path.join(os.homedir(), 'OneDrive', 'Desktop');
        if (fs.existsSync(oneDriveDesktop)) {
            DesktopPath = oneDriveDesktop;
        }
    }

    const FolderCreatePath = path.join(DesktopPath, 'DESKTOP SHARE');
    if (!fs.existsSync(FolderCreatePath)) {
        fs.mkdirSync(FolderCreatePath);
        console.log(`✅ Created folder at: ${FolderCreatePath}`);
    } else {
        console.log(`📂 Folder already exists at: ${FolderCreatePath}`);
    }
};
