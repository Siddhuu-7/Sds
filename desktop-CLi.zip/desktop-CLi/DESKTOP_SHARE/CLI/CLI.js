const readline = require('readline');
const chalk = require('chalk');
const SenderCLI = require('../Sender_CLI/SENDER_CLI/Sender_CLI');
const Udp=require("../UDP/udp")
class TCPFileTransferCLI {
    constructor() {
       
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            prompt: chalk.green('💬 Do you want to send or receive a file? ') + chalk.gray('(send/receive): ')
        });
    }

    showBanner() {
        const boxTop = chalk.yellow('╔' + '═'.repeat(42) + '╗');
        const boxMid = chalk.yellow('║') + chalk.bold.green('  📦 Welcome to TCP File Transfer CLI     ') + chalk.yellow('║');
        const boxBot = chalk.yellow('╚' + '═'.repeat(42) + '╝');
        console.log('\n' + boxTop + '\n' + boxMid + '\n' + boxBot + '\n');
    }

    start() {
        this.showBanner();
        this.rl.prompt();

        this.rl.on('line', (answer) => this.handleInput(answer));
    }

    handleInput(input) {
        const choice = input.trim().toLowerCase();

        if (choice === 'send') {
            console.log(chalk.cyanBright('\n🚀 Starting Sender Module...\n'));
            this.rl.close();
            console.clear();

            SenderCLI();
            

        } else if (choice === 'receive' || choice === 'recieve') {
            console.log(chalk.cyanBright('\n📥 Starting Receiver Module...\n'));
            this.rl.close();
            console.clear();

            require('../Reciver_CLI/reciver');

        } else {
            console.log(chalk.red(`\n❌ Invalid option: ${choice}. Please enter "send" or "receive".\n`));
            this.rl.prompt();
        }
    }
}

const app = new TCPFileTransferCLI();
app.start();
