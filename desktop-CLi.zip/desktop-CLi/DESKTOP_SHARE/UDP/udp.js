const dgram = require("dgram");
const os = require("os");
const getIp = require("./getIp").getIp;

class Broadcaster {
    constructor(port = 41234, interval = 3000) {
        this.port = port;
        this.interval = interval;
      this.udpServer = dgram.createSocket({ type: "udp4", reuseAddr: true });

        this.Ips = new Set();
        this.deviceName = os.hostname();
        this.IP = getIp();
        this.timer = null;
    }

    
async init() {
    let tries = 0;
    while (tries < 5) {
        try {
            await new Promise((resolve, reject) => {
                this.udpServer.once("error", reject);
                this.udpServer.bind(this.port, () => {
                    this.udpServer.setBroadcast(true);
                    console.log(`[INFO] UDP socket bound on port ${this.port}`);
                    resolve();
                });
            });
            return;
        } catch (err) {
            if (err.code === "EADDRINUSE") {
                console.warn(`[WARN] Port ${this.port} in use. Retrying on ${this.port + 1}...`);
                this.port++;
                tries++;
            } else throw err;
        }
    }
    throw new Error("Failed to bind UDP socket after multiple attempts.");
}


    start() {
        this.timer = setInterval(() => this.broadcast(), this.interval);
    }

    broadcast() {
        const message = Buffer.from(`${this.IP},${this.deviceName}`);
        this.udpServer.send(message, 0, message.length, this.port, "255.255.255.255", err => {
            if (err) console.error("[ERROR] Broadcast failed:", err);
        });

        if (!this.Ips.has(this.IP)) {
            this.Ips.add(this.IP);
            console.log(`[BROADCAST] ${this.deviceName} (${this.IP})`);
        }
    }

    stop() {
        if (this.timer) clearInterval(this.timer);
        this.udpServer.close(() => console.log("[INFO] UDP Broadcast stopped"));
    }

    listener(callback) {
        this.udpServer.on("message", (msg, rinfo) => {
            const message = msg.toString();
            callback(message, rinfo);
        });
    }
}

module.exports = Broadcaster;
