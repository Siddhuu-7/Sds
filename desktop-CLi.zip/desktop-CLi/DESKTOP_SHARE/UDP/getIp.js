const os = require('os');
const getIp = () => {
    const interfaces = os.networkInterfaces();
    for (const key in interfaces) {
        for (const net of interfaces[key]) {
            if (net.family === 'IPv4' && !net.internal) {
                return net.address;
            }
        }
    }
    return null;
};
module.exports={getIp}