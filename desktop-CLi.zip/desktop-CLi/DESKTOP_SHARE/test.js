const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

const pythonDir = path.join(__dirname, '..'); 

exec('python DESKTOP_SHARE/main.py',  (error, stdout, stderr) => {
    if (error) {
        console.error(chalk.red(`❌ Python exec error: ${error.message}`));
        return;
    }
    if (stderr) {
        console.warn(chalk.yellow(`⚠️ Python stderr: ${stderr}`));
    }

    const filePath = fs.readFileSync( 'FilePaths.txt', 'utf-8').trim();
    if (!filePath) {
        console.log(chalk.red('❌ No file selected.'));
    } else {
        console.log(chalk.green(`✅ Selected file path: ${filePath}`));
    }
});
