const fs=require('fs')
module.exports=(userFilePath)=>{
    const isvalid=fs.existsSync(userFilePath)
    return isvalid
}