const { exec } = require("child_process");
const fs = require("fs");
const path = require("path");

class FolderOperations {
    constructor() {
        this.zipPath = path.join(__dirname, "../../../ZIPS");

        if (!fs.existsSync(this.zipPath)) {
            fs.mkdirSync(this.zipPath, { recursive: true });
        }
    }

    zippping(folderPath) {
        return new Promise((resolve, reject) => {
            const folderName = path.basename(folderPath);
            const zipFilePath = path.join(this.zipPath, folderName + ".zip");

            exec(`powershell Compress-Archive -Path "${folderPath}\\*" -DestinationPath "${zipFilePath}"`, (err, stdout, stderr) => {
                if (err) return reject(err);
                resolve(zipFilePath);
            });
        });
    }
   unZipping(zipFilePath, destinationDir) {
    return new Promise((resolve, reject) => {
        const zipName = path.basename(zipFilePath, ".zip");
        const extractPath = path.join(destinationDir, zipName);
        const command = `powershell -Command "Expand-Archive -Force '${zipFilePath}' '${extractPath}'"`;
        exec(command, (err, stdout, stderr) => {
            if (err) {
                console.error("Unzip failed:", stderr);
                return reject(err);
            }
            this.unlink(zipFilePath);
            resolve(extractPath);
        });
    });
}
    unlink(zipPath) {
        fs.unlink(zipPath, (err) => {
            if (err) console.error("❌ Failed to delete file:", err);
        });
    }
}

module.exports = FolderOperations;
