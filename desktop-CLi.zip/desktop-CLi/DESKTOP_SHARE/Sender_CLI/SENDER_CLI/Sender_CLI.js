const chalk = require('chalk');
const sender_Module = require('../sender');
const { exec } = require('child_process');
const fs = require('fs');
const inquirer = require('inquirer');
const path = require('path');
const UDP = require('../../UDP/udp');

async function startSenderCLI() {
    const Udp = new UDP();
    await Udp.init();

    console.log(chalk.blueBright.bold(`\n📦 Welcome to TCP File Transfer ${chalk.yellow('Sender')} CLI\n`));

    async function askForIP() {
        const devices = new Set();

        console.log(chalk.blueBright.bold(`\n🔍 Searching for devices...\n`));

        
        Udp.listener(msg => devices.add(msg));

 s
        await new Promise(res => setTimeout(res, 5000));

        const choices = [];
        devices.forEach(value => {
            const [ip, name] = value.split(',');
            if (ip && name) {
                choices.push({ name, value: ip });
            }
        });

        if (choices.length === 0) {
            const { Retry } = await inquirer.prompt([
                {
                    type: 'list',
                    name: 'Retry',
                    message: chalk.blue('No devices found.'),
                    choices: [
                        { name: '🔁 Retry Again', value: true },
                        { name: '❌ Exit', value: false },
                    ],
                },
            ]);

            if (Retry) return askForIP();
            process.exit(0);
        }

        const { Ips } = await inquirer.prompt([
            {
                type: 'list',
                name: 'Ips',
                message: chalk.green('Select Receiver:'),
                choices,
            },
        ]);

        await askForPath(Ips);
    }

    async function askForPath(ip) {
        const { choice } = await inquirer.prompt([
            {
                type: 'list',
                name: 'choice',
                message: chalk.green('📂 Select an option:'),
                choices: [
                    { name: '📁 Open File Manager and Choose a File', value: 'open' },
                    { name: '❌ Exit', value: 'exit' },
                ],
            },
        ]);

        if (choice === 'exit') {
            console.log(chalk.yellow('\n👋 Exiting TCP Sender CLI.\n'));
            process.exit(0);
        }

        if (choice === 'open') {
            const exePath = path.join(__dirname, 'main.exe');
            exec(exePath, (error, stdout, stderr) => {
                if (error) {
                    console.error(chalk.red(`❌ Exec error: ${error.message}`));
                    return askForPath(ip);
                }

                if (stderr) {
                    console.warn(chalk.yellow(`⚠️ stderr: ${stderr}`));
                }

                const filepath = stdout.trim();

                if (!filepath) {
                    console.log(chalk.red('❌ No file selected.'));
                    return askForPath(ip);
                }

                console.log(chalk.green(`✅ Selected file: ${filepath}`));
                sender_Module(filepath, ip, () => {
                    console.log(chalk.magentaBright('🔁 Ready for next file.\n'));
                    askForPath(ip);
                });
            });
        }
    }

    await askForIP();
}

module.exports = startSenderCLI;
