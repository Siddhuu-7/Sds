
const chalk = require('chalk');
const sender_Module = require('../sender');
const { exec } = require('child_process');
const fs = require('fs');
const inquirer = require('inquirer'); 
const path = require('path');
const UDP=require("../../UDP/udp");

 async function startSenderCLI() {
const Udp=new UDP()
await Udp.init()
const devices=new Set()
const choices=[]
    console.log(chalk.blueBright.bold(`\n📦 Welcome to TCP File Transfer ${chalk.yellow('Sender')} CLI\n`));

    function askForIP() { 
       Udp.listener(msg=>{
    devices.add(msg)
})
console.log(chalk.blueBright.bold(`\n🔍Searching For Devices\n`));
setTimeout(()=>{
devices.forEach((value,value2)=>{
    let d=value2.split(",")
        choices.push({
            name:d[1],
            value:d[0]
        })
})
},5000)
    setTimeout(()=>{
        inquirer.prompt([
        {
            type:"list",
            name:"Ips",
            message:chalk.green("Select Reciver"),
            choices:[
                ...choices
            ]
        }
    ]).then(ip=>
    {
        if(ip){  
            askForPath(ip.Ips)
        }else{
          return  askForIP()
        }
    }
    )
    },5000)
    }

    function askForPath(ip) {
        inquirer.prompt([
            {
                type: 'list',
                name: 'choice',
                message: chalk.green('📂 Select an option:'),
                choices: [
                    { name: '📁 Open File Manager and Choose a File', value: 'open' },
                    { name: '❌ Exit', value: 'exit' },
                ],
            },
        ]).then((answers) => {
            if (answers.choice === 'exit') {
                console.log(chalk.yellow('\n👋 Exiting TCP Sender CLI.\n'));
                return;
            }

            if (answers.choice === 'open') {
                const exePath = path.join(__dirname,"main.exe");
                exec(exePath, (error, stdout, stderr) => {
                    if (error) {
                        console.error(chalk.red(`❌ Exec error: ${error.message}`));
                        askForPath(ip);
                        return;
                    }
                    if (stderr) {
                        console.warn(chalk.yellow(`⚠️ stderr: ${stderr}`));
                    }

                    const filepath = fs.readFileSync('FilePaths.txt', 'utf-8').trim();
                    if (!filepath) {
                        console.log(chalk.red('❌ No file selected.'));
                        askForPath(ip);
                    } else {
                        console.log(chalk.green(`✅ Selected file path: ${filepath}`));
                        sender_Module(filepath, ip, () => {
                            console.log(chalk.magentaBright('🔁 Ready for next file.\n'));
                            askForPath(ip);
                        });
                    }
                });
            }
        });
    }

    askForIP();
}

module.exports = startSenderCLI;
