
import tkinter as tk
from tkinter import filedialog, messagebox
import sys
import os
root = tk.Tk()
root.withdraw()
sys.stdout.reconfigure(encoding='utf-8')
choice = messagebox.askyesno("Selection Type", "Do you want to select a folder instead of a file?")
if choice:
    selected_path = filedialog.askdirectory(title="Select Folder")
else:
    selected_path = filedialog.askopenfilename(title="Select File")
if selected_path:
    with open('FilePaths.txt', 'w', encoding="utf-8") as file:
        file.write(selected_path)
    print(selected_path)

