const fs = require('fs');
const net = require('net');
const path = require('path');
const ZIP = require("./SENDER_CLI/FolderOPeration/FolderZip");

module.exports = (userFilePath, IPAddress, onComplete) => {
    const PORT = 6961;
    const IP = IPAddress;
    let PATH = String.raw`${userFilePath}`;
    let fileName = PATH.split('/').pop();
    console.log("fileName:", fileName);
    console.log("PATH exists:", fs.existsSync(PATH));

    const zip = new ZIP();

    const proceedToSend = () => {
        const sender = new net.Socket();

        sender.connect(PORT, IP, () => {
            console.log('\n✅ Connected to Receiver');
            sender.write(fileName + '\n');

            sender.setNoDelay(true);
            const filestream = fs.createReadStream(PATH, { highWaterMark: 8 * 1024 * 1024 });

            filestream.pipe(sender);

            filestream.on('end', () => {
                console.log('📤 File stream ended.');
                sender.end();
            });

            filestream.on('error', (err) => {
                console.error('❌ File stream error:', err);
                sender.destroy();
            });
        });

        sender.on('data', (data) => {
            console.log('📨 Receiver response:', data.toString());
        });

        sender.on('error', (err) => {
            console.log('❌ Socket Error:', err);
            zip.unlink(PATH); 
        });

        sender.on('close', () => {
            console.log('🔒 Connection closed\n');
            zip.unlink(PATH); 
            if (onComplete) onComplete();
        });
    };

    try {
        const stat = fs.statSync(PATH);
        if (stat.isDirectory()) {
            
            fileName=`${fileName}.zip`
            zip.zippping(PATH)
                .then(zipPath => {
                    PATH = zipPath;
                    proceedToSend();
                })
                .catch(err => console.error("❌ Zipping failed:", err));
        } else {
            // It's a file, send directly
            proceedToSend();
        }
    } catch (error) {
        console.log('❌ Sender Error:', error);
    }
};
